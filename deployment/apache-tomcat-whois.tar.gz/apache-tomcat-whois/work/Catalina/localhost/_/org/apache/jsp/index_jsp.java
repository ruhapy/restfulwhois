package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import java.util.*;
import net.sf.json.JSONObject;
import java.security.Principal;
import com.cnnic.whois.util.WhoisProperties;
import java.util.*;

public final class index_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  static {
    _jspx_dependants = new java.util.ArrayList(2);
    _jspx_dependants.add("/WEB-INF/comm/queryIndex.jsp");
    _jspx_dependants.add("/META-INF/cnnic.tld");
  }

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fc_005fif_0026_005ftest;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fcnnic_005fpage_0026_005fpageBeanName_005fmaxShowPage_005fmaxRecordConfigurable_005fid_005fhref_005fnobody;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fc_005fif_0026_005ftest = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fcnnic_005fpage_0026_005fpageBeanName_005fmaxShowPage_005fmaxRecordConfigurable_005fid_005fhref_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.release();
    _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.release();
    _005fjspx_005ftagPool_005fcnnic_005fpage_0026_005fpageBeanName_005fmaxShowPage_005fmaxRecordConfigurable_005fid_005fhref_005fnobody.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=utf-8");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<!DOCTYPE html PUBLIC \"-//W3C//DTD HTML 4.01//EN\" \"http://www.w3.org/TR/html4/strict.dtd\">\r\n");
      out.write("<html>\r\n");
      out.write("\t<head>\r\n");
      out.write("\t\t<title>Restful Whois</title>\r\n");
      out.write("\r\n");
      out.write("\t\t<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\r\n");
      out.write("\r\n");
      out.write("\t\t<link href=\"");
      if (_jspx_meth_c_005furl_005f0(_jspx_page_context))
        return;
      out.write("\" type=\"text/css\"\r\n");
      out.write("\t\t\trel=\"stylesheet\" />\r\n");
      out.write("\r\n");
      out.write("\t\t<script type=\"text/javascript\"\r\n");
      out.write("\t\t\tsrc=\"");
      if (_jspx_meth_c_005furl_005f1(_jspx_page_context))
        return;
      out.write("\"></script>\r\n");
      out.write("\t\t<script type=\"text/javascript\" src=\"");
      if (_jspx_meth_c_005furl_005f2(_jspx_page_context))
        return;
      out.write("\"></script>\r\n");
      out.write("\t\t<script type=\"text/javascript\"\r\n");
      out.write("\t\t\tsrc=\"");
      if (_jspx_meth_c_005furl_005f3(_jspx_page_context))
        return;
      out.write("\" charset=\"utf-8\"></script>\r\n");
      out.write("\t\t<script language=\"javascript\">\r\n");
      out.write("\tfunction go() {\r\n");
      out.write("\t\tvar event = window.event || arguments.callee.caller.arguments[0];\r\n");
      out.write("\t\tif (event.keyCode == 13) {\r\n");
      out.write("\t\t\tdocument.getElementById(\"go\").click();\r\n");
      out.write("\t\t\treturn false;\r\n");
      out.write("\t\t}\r\n");
      out.write("\t}\r\n");
      out.write("</script>\r\n");
      out.write("\t</head>\r\n");
      out.write("\t<body>\r\n");
      out.write("\t\t");

			Principal user = request.getUserPrincipal();
			String username = "";
			String openIdName = null;
			if (user != null) {
				if (!request.isUserInRole("administrator")) {
					username = user.getName();
				}else{
					user = null;
				}
			}else if(request.getSession().getAttribute("openIdUser") != null){
				openIdName = "openIdName";
				username = (String)request.getSession().getAttribute("openIdUser");
				if(username != null && username.startsWith("http://")){
					username = username.substring("http://".length());
				}
			}
			
			request.setAttribute("user", user);
			request.setAttribute("openIdName", openIdName);
			JSONObject jsonObject = (JSONObject) request
					.getAttribute("JsonObject");
					
			String queryType = "";
			String queryPara = "";
			String queryFormat = "";
			if (request.getAttribute("queryType") != null){
				queryType = (String)request.getAttribute("queryType");
				if(null != request.getAttribute("queryPara")){
					queryPara = (String)request.getAttribute("queryPara");
				}
				queryFormat = (String)request.getAttribute("queryFormat");
			}
		
      out.write("\r\n");
      out.write("\t\t<input type=\"hidden\" value='");
      out.print(request.getContextPath()+"/"+WhoisProperties.getRdapUrl());
      out.write("'\r\n");
      out.write("\t\t\tid=\"pathUrl\" />\r\n");
      out.write("\t\t<div id=\"wrapper\">\r\n");
      out.write("\t\t\t<div id=\"header\">\r\n");
      out.write("\t\t\t\t<h1>\r\n");
      out.write("\t\t\t\t\t<a href=\"");
      out.print(request.getContextPath());
      out.write("/index.jsp\"><acronym>Restful Whois</acronym> </a>\r\n");
      out.write("\t\t\t\t</h1>\r\n");
      out.write("\t\t\t\t<ul id=\"menu\">\r\n");
      out.write("\t\t\t\t\t<li class=\"one\">\r\n");
      out.write("\t\t\t\t\t\t<dl>\r\n");
      out.write("\t\t\t\t\t\t\t<dt>\r\n");
      out.write("\t\t\t\t\t\t\t\t<a href=\"");
      out.print(request.getContextPath()+"/"+WhoisProperties.getRdapUrl());
      out.write("/help\">Help</a>\r\n");
      out.write("\t\t\t\t\t\t\t</dt>\r\n");
      out.write("\t\t\t\t\t\t</dl>\r\n");
      out.write("\t\t\t\t\t</li>\r\n");
      out.write("\t\t\t\t\t<li class=\"one\">\r\n");
      out.write("\t\t\t\t\t\t<dl>\r\n");
      out.write("\t\t\t\t\t\t\t<dt>\r\n");
      out.write("\t\t\t\t\t\t\t\t<a href=\"\" onclick=\"aboutContent();return false\">About Us</a>\r\n");
      out.write("\t\t\t\t\t\t\t</dt>\r\n");
      out.write("\t\t\t\t\t\t</dl>\r\n");
      out.write("\t\t\t\t\t</li>\r\n");
      out.write("\t\t\t\t\t");
if (openIdName == null && user == null) {
      out.write("\r\n");
      out.write("\t\t\t\t\t<li class=\"two\">\r\n");
      out.write("\t\t\t\t\t\t<dl>\r\n");
      out.write("\t\t\t\t\t\t\t<dt>\r\n");
      out.write("\t\t\t\t\t\t\t\t<a href=\"");
      if (_jspx_meth_c_005furl_005f4(_jspx_page_context))
        return;
      out.write("\">Login</a>\r\n");
      out.write("\t\t\t\t\t\t\t</dt>\r\n");
      out.write("\t\t\t\t\t\t</dl>\r\n");
      out.write("\t\t\t\t\t</li>\r\n");
      out.write("\t\t\t\t\t<li class=\"four\">\r\n");
      out.write("\t\t\t\t\t\t<dl>\r\n");
      out.write("\t\t\t\t\t\t\t<dt>\r\n");
      out.write("\t\t\t\t\t\t\t\t<a href=\"");
      if (_jspx_meth_c_005furl_005f5(_jspx_page_context))
        return;
      out.write("\">OpenId Login</a>\r\n");
      out.write("\t\t\t\t\t\t\t</dt>\r\n");
      out.write("\t\t\t\t\t\t</dl>\r\n");
      out.write("\t\t\t\t\t</li>\r\n");
      out.write("\t\t\t\t\t");
} else {
      out.write("\r\n");
      out.write("\t\t\t\t\t<li class=\"six\">\r\n");
      out.write("\t\t\t\t\t\t<dl>\r\n");
      out.write("\t\t\t\t\t\t\t<dt>\r\n");
      out.write("\t\t\t\t\t\t\t\t<font>Current User: <big style=\"color: red\">");
      out.print(username);
      out.write("</big>\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\t\t</font>\r\n");
      out.write("\t\t\t\t\t\t\t</dt>\r\n");
      out.write("\t\t\t\t\t\t</dl>\r\n");
      out.write("\t\t\t\t\t</li>\r\n");
      out.write("\t\t\t\t\t<li class=\"five\">\r\n");
      out.write("\t\t\t\t\t\t<dl>\r\n");
      out.write("\t\t\t\t\t\t\t<dt>\r\n");
      out.write("\t\t\t\t\t\t\t\t<a href=\"");
      if (_jspx_meth_c_005furl_005f6(_jspx_page_context))
        return;
      out.write("\">logout</a>\r\n");
      out.write("\t\t\t\t\t\t\t</dt>\r\n");
      out.write("\t\t\t\t\t\t</dl>\r\n");
      out.write("\t\t\t\t\t</li>\r\n");
      out.write("\t\t\t\t\t");
}
      out.write("\r\n");
      out.write("\t\t\t\t</ul>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t<div id=\"sidebar\">\r\n");
      out.write("\t\t\t\t<div id=\"web_services\">\r\n");
      out.write("\t\t\t\t\t<fieldset>\r\n");
      out.write("\t\t\t\t\t\t<legend>\r\n");
      out.write("\t\t\t\t\t\t\t<span>Restful Whois</span>\r\n");
      out.write("\t\t\t\t\t\t</legend>\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\t\t\t\t\t\t<hr />\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t<input id=\"optionType\" type=\"radio\" name=\"optionType\" value=\"ip\"\r\n");
      out.write("\t\t\t\t\t\t\tchecked=\"checked\" />\r\n");
      out.write("\t\t\t\t\t\t<span>IP</span>\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t<input id=\"optionType\" name=\"optionType\" type=\"radio\"\r\n");
      out.write("\t\t\t\t\t\t\t");

							if (queryType.equals("domain")) {
						 
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\tchecked=\"checked\" ");
} 
      out.write(" value=\"domain\" />\r\n");
      out.write("\t\t\t\t\t\t<span>Domain Query</span>\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t<input id=\"optionType\" type=\"radio\" name=\"optionType\"\r\n");
      out.write("\t\t\t\t\t\t\t");

							if (queryType.equals("entity")) {
						 
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\tchecked=\"checked\" ");
} 
      out.write(" value=\"entity\" />\r\n");
      out.write("\t\t\t\t\t\t<span>Entity</span>\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t<input id=\"optionType\" type=\"radio\" name=\"optionType\"\r\n");
      out.write("\t\t\t\t\t\t\t");

							if (queryType.equals("autnum")) {
						 
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\tchecked=\"checked\" ");
} 
      out.write(" value=\"autnum\" />\r\n");
      out.write("\t\t\t\t\t\t<span>Autonomous System</span>\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t<input id=\"optionType\" type=\"radio\" name=\"optionType\"\r\n");
      out.write("\t\t\t\t\t\t\t");

							if (queryType.equals("nameserver")) {
						 
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\tchecked=\"checked\" ");
} 
      out.write(" value=\"nameserver\" />\r\n");
      out.write("\t\t\t\t\t\t<span>Name Server</span>\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\t\t\t\t\t\t<hr />\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t<input id=\"showType\" name=\"showType\" type=\"radio\"\r\n");
      out.write("\t\t\t\t\t\t\t");

							if (queryType.equals("application/json")) {
						 
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\tchecked=\"checked\" ");
} 
      out.write(" value=\"json\">\r\n");
      out.write("\t\t\t\t\t\t<span>JSON Format</span>\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t<input id=\"showType\" name=\"showType\" type=\"radio\"\r\n");
      out.write("\t\t\t\t\t\t\t");

							if (queryType.equals("application/xml")) {
						 
      out.write("\r\n");
      out.write("\t\t\t\t\t\t\tchecked=\"checked\" ");
} 
      out.write(" value=\"xml\">\r\n");
      out.write("\t\t\t\t\t\t<span>XML Format</span>\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t<input id=\"showType\" name=\"showType\" type=\"radio\" value=\"html\"\r\n");
      out.write("\t\t\t\t\t\t\tchecked=\"checked\">\r\n");
      out.write("\t\t\t\t\t\t<span>Presentation Format</span>\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\t\t\t\t\t\t<hr />\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\r\n");
      out.write("\t\t\t\t\t\t<input size=\"20\" id=\"queryInfo\" type=\"text\" onkeydown=\"go()\"\r\n");
      out.write("\t\t\t\t\t\t\tvalue=\"");
      out.print(queryPara );
      out.write("\" />\r\n");
      out.write("\t\t\t\t\t\t<input type=\"button\" value=\"go\" onclick=\"processQuery()\" id='go' />\r\n");
      out.write("\t\t\t\t\t\t<br />\r\n");
      out.write("\t\t\t\t\t</fieldset>\r\n");
      out.write("\t\t\t\t</div>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t<div id=\"content\">\r\n");
      out.write("\t\t\t\t<div id=\"maincontent\">");
      out.print(jsonObject);
      out.write("</div>\r\n");
      out.write("\t\t\t\t<div id=\"jsoncontent\"></div>\r\n");
      out.write("\t\t\t</div>\r\n");
      out.write("\t\t\t");
      if (_jspx_meth_c_005fif_005f0(_jspx_page_context))
        return;
      out.write("\r\n");
      out.write("\t\t\t<div style=\"clear: both;\"></div>\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t\t<div id=\"footer\">\r\n");
      out.write("\t\t\t<p>\r\n");
      out.write("\t\t\t\tBy using the Restful Whois service, you are agreeing to the Whois Terms of Use\r\n");
      out.write("\t\t\t\t<br />\r\n");
      out.write("\t\t\t\t&copy; Copyright 2013, CNNIC & ICANN\r\n");
      out.write("\t\t\t</p>\r\n");
      out.write("\t\t\t<img name='image1' alt=\"\" src=\"/image/cnnicLogo.jpg\">\r\n");
      out.write("\t\t\t<img alt=\"\" name='image2' src=\"");
      if (_jspx_meth_c_005furl_005f7(_jspx_page_context))
        return;
      out.write("\">\r\n");
      out.write("\t\t</div>\r\n");
      out.write("\t</body>\r\n");
      out.write("</html>");
      out.write('\r');
      out.write('\n');
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
        else log(t.getMessage(), t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_c_005furl_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_005furl_005f0 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_005furl_005f0.setPageContext(_jspx_page_context);
    _jspx_th_c_005furl_005f0.setParent(null);
    // /WEB-INF/comm/queryIndex.jsp(16,14) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005furl_005f0.setValue("/css/whois-style.css");
    int _jspx_eval_c_005furl_005f0 = _jspx_th_c_005furl_005f0.doStartTag();
    if (_jspx_th_c_005furl_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f0);
    return false;
  }

  private boolean _jspx_meth_c_005furl_005f1(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_005furl_005f1 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_005furl_005f1.setPageContext(_jspx_page_context);
    _jspx_th_c_005furl_005f1.setParent(null);
    // /WEB-INF/comm/queryIndex.jsp(20,8) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005furl_005f1.setValue("/js/jquery-1.6.2.min.js");
    int _jspx_eval_c_005furl_005f1 = _jspx_th_c_005furl_005f1.doStartTag();
    if (_jspx_th_c_005furl_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f1);
    return false;
  }

  private boolean _jspx_meth_c_005furl_005f2(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_005furl_005f2 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_005furl_005f2.setPageContext(_jspx_page_context);
    _jspx_th_c_005furl_005f2.setParent(null);
    // /WEB-INF/comm/queryIndex.jsp(21,38) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005furl_005f2.setValue("/js/json2.js");
    int _jspx_eval_c_005furl_005f2 = _jspx_th_c_005furl_005f2.doStartTag();
    if (_jspx_th_c_005furl_005f2.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f2);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f2);
    return false;
  }

  private boolean _jspx_meth_c_005furl_005f3(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_005furl_005f3 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_005furl_005f3.setPageContext(_jspx_page_context);
    _jspx_th_c_005furl_005f3.setParent(null);
    // /WEB-INF/comm/queryIndex.jsp(23,8) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005furl_005f3.setValue("/js/whois-query.js");
    int _jspx_eval_c_005furl_005f3 = _jspx_th_c_005furl_005f3.doStartTag();
    if (_jspx_th_c_005furl_005f3.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f3);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f3);
    return false;
  }

  private boolean _jspx_meth_c_005furl_005f4(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_005furl_005f4 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_005furl_005f4.setPageContext(_jspx_page_context);
    _jspx_th_c_005furl_005f4.setParent(null);
    // /WEB-INF/comm/queryIndex.jsp(95,17) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005furl_005f4.setValue("/adv/advindex.jsp");
    int _jspx_eval_c_005furl_005f4 = _jspx_th_c_005furl_005f4.doStartTag();
    if (_jspx_th_c_005furl_005f4.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f4);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f4);
    return false;
  }

  private boolean _jspx_meth_c_005furl_005f5(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_005furl_005f5 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_005furl_005f5.setPageContext(_jspx_page_context);
    _jspx_th_c_005furl_005f5.setParent(null);
    // /WEB-INF/comm/queryIndex.jsp(102,17) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005furl_005f5.setValue("/openIdLogin.jsp");
    int _jspx_eval_c_005furl_005f5 = _jspx_th_c_005furl_005f5.doStartTag();
    if (_jspx_th_c_005furl_005f5.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f5);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f5);
    return false;
  }

  private boolean _jspx_meth_c_005furl_005f6(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_005furl_005f6 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_005furl_005f6.setPageContext(_jspx_page_context);
    _jspx_th_c_005furl_005f6.setParent(null);
    // /WEB-INF/comm/queryIndex.jsp(119,17) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005furl_005f6.setValue("/adv/logout.jsp");
    int _jspx_eval_c_005furl_005f6 = _jspx_th_c_005furl_005f6.doStartTag();
    if (_jspx_th_c_005furl_005f6.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f6);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f6);
    return false;
  }

  private boolean _jspx_meth_c_005fif_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:if
    org.apache.taglibs.standard.tag.rt.core.IfTag _jspx_th_c_005fif_005f0 = (org.apache.taglibs.standard.tag.rt.core.IfTag) _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.get(org.apache.taglibs.standard.tag.rt.core.IfTag.class);
    _jspx_th_c_005fif_005f0.setPageContext(_jspx_page_context);
    _jspx_th_c_005fif_005f0.setParent(null);
    // /WEB-INF/comm/queryIndex.jsp(207,3) name = test type = boolean reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005fif_005f0.setTest(((java.lang.Boolean) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${pageBean != null}", java.lang.Boolean.class, (PageContext)_jspx_page_context, null, false)).booleanValue());
    int _jspx_eval_c_005fif_005f0 = _jspx_th_c_005fif_005f0.doStartTag();
    if (_jspx_eval_c_005fif_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      do {
        out.write("\r\n");
        out.write("\t\t\t\t");
        if (_jspx_meth_cnnic_005fpage_005f0(_jspx_th_c_005fif_005f0, _jspx_page_context))
          return true;
        out.write("\r\n");
        out.write("\t\t\t");
        int evalDoAfterBody = _jspx_th_c_005fif_005f0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
    }
    if (_jspx_th_c_005fif_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005fif_0026_005ftest.reuse(_jspx_th_c_005fif_005f0);
    return false;
  }

  private boolean _jspx_meth_cnnic_005fpage_005f0(javax.servlet.jsp.tagext.JspTag _jspx_th_c_005fif_005f0, PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  cnnic:page
    com.cnnic.whois.util.PageTag _jspx_th_cnnic_005fpage_005f0 = (com.cnnic.whois.util.PageTag) _005fjspx_005ftagPool_005fcnnic_005fpage_0026_005fpageBeanName_005fmaxShowPage_005fmaxRecordConfigurable_005fid_005fhref_005fnobody.get(com.cnnic.whois.util.PageTag.class);
    _jspx_th_cnnic_005fpage_005f0.setPageContext(_jspx_page_context);
    _jspx_th_cnnic_005fpage_005f0.setParent((javax.servlet.jsp.tagext.Tag) _jspx_th_c_005fif_005f0);
    // /WEB-INF/comm/queryIndex.jsp(208,4) name = href type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_cnnic_005fpage_005f0.setHref((java.lang.String) org.apache.jasper.runtime.PageContextImpl.proprietaryEvaluate("${queryPath}", java.lang.String.class, (PageContext)_jspx_page_context, null, false));
    // /WEB-INF/comm/queryIndex.jsp(208,4) name = pageBeanName type = null reqTime = true required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_cnnic_005fpage_005f0.setPageBeanName("pageBean");
    // /WEB-INF/comm/queryIndex.jsp(208,4) name = maxShowPage type = java.lang.String reqTime = false required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_cnnic_005fpage_005f0.setMaxShowPage(5);
    // /WEB-INF/comm/queryIndex.jsp(208,4) name = maxRecordConfigurable type = java.lang.String reqTime = false required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_cnnic_005fpage_005f0.setMaxRecordConfigurable(false);
    // /WEB-INF/comm/queryIndex.jsp(208,4) name = id type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_cnnic_005fpage_005f0.setId("1");
    int _jspx_eval_cnnic_005fpage_005f0 = _jspx_th_cnnic_005fpage_005f0.doStartTag();
    if (_jspx_th_cnnic_005fpage_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fcnnic_005fpage_0026_005fpageBeanName_005fmaxShowPage_005fmaxRecordConfigurable_005fid_005fhref_005fnobody.reuse(_jspx_th_cnnic_005fpage_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fcnnic_005fpage_0026_005fpageBeanName_005fmaxShowPage_005fmaxRecordConfigurable_005fid_005fhref_005fnobody.reuse(_jspx_th_cnnic_005fpage_005f0);
    return false;
  }

  private boolean _jspx_meth_c_005furl_005f7(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  c:url
    org.apache.taglibs.standard.tag.rt.core.UrlTag _jspx_th_c_005furl_005f7 = (org.apache.taglibs.standard.tag.rt.core.UrlTag) _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.get(org.apache.taglibs.standard.tag.rt.core.UrlTag.class);
    _jspx_th_c_005furl_005f7.setPageContext(_jspx_page_context);
    _jspx_th_c_005furl_005f7.setParent(null);
    // /WEB-INF/comm/queryIndex.jsp(219,34) name = value type = null reqTime = true required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_c_005furl_005f7.setValue("/image/icannLogo.jpg");
    int _jspx_eval_c_005furl_005f7 = _jspx_th_c_005furl_005f7.doStartTag();
    if (_jspx_th_c_005furl_005f7.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f7);
      return true;
    }
    _005fjspx_005ftagPool_005fc_005furl_0026_005fvalue_005fnobody.reuse(_jspx_th_c_005furl_005f7);
    return false;
  }
}
